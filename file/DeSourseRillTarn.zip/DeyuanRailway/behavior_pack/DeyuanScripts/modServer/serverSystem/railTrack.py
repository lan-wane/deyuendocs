# -*- coding: utf-8 -*-
"""
德元轨道交通 - 原版铁轨(矿车铁轨)线路追踪
把玩家铺设的原版铁轨网络追踪为连续路径, 再用 TrainTrack 构建平滑样条, 供列车行驶
- 铁轨方块: minecraft:rail / golden_rail / detector_rail / activator_rail
- 支持直轨、弯轨、上坡轨
- get_block(pos) -> 方块名 或 None (由调用方注入, 便于测试)
"""

from DeyuanScripts.modServer.serverSystem.trainTrack import TrainTrack

RAIL_BLOCKS = (
    "minecraft:rail",
    "minecraft:golden_rail",
    "minecraft:detector_rail",
    "minecraft:activator_rail",
)

# 铁轨方块数据值(形状) -> 连接偏移(位置级, 含上坡的 y+1)
RAIL_CONNS = {
    0: [(0, 0, -1), (0, 0, 1)],      # 直 N-S
    1: [(1, 0, 0), (-1, 0, 0)],      # 直 E-W
    2: [(-1, 0, 0), (1, 1, 0)],      # 上坡东(西低东高)
    3: [(1, 0, 0), (-1, 1, 0)],      # 上坡西
    4: [(0, 0, 1), (0, 1, -1)],      # 上坡北(南低北高)
    5: [(0, 0, -1), (0, 1, 1)],      # 上坡南
    6: [(0, 0, 1), (1, 0, 0)],       # 弯 SE
    7: [(0, 0, 1), (-1, 0, 0)],      # 弯 SW
    8: [(0, 0, -1), (-1, 0, 0)],     # 弯 NW
    9: [(0, 0, -1), (1, 0, 0)],      # 弯 NE
}

MAX_TRACE = 2000   # 最大追踪铁轨块数


def _name_aux(block):
    """归一化 get_block 返回值 -> (名称, 数据值)"""
    if isinstance(block, tuple):
        name = block[0] or ""
        aux = block[1] if len(block) > 1 else 0
    else:
        name = block or ""
        aux = 0
    return name, aux


def _is_rail(block):
    name, _ = _name_aux(block)
    return name in RAIL_BLOCKS


def rail_data(block_name, aux):
    """取铁轨形状数据(0-9)。普通铁轨直接取 aux; 充能/探测/激活轨形状只有 0-5, 屏蔽电源位"""
    if block_name == "minecraft:rail":
        return aux & 15
    return aux & 7


def trace_rails(get_block, start_rail, max_len=MAX_TRACE):
    """
    get_block((x,y,z)) -> 方块名或None
    start_rail: (x,y,z) 起始铁轨方块坐标
    返回: ([(x,y,z), ...], is_loop 是否闭环)
    单向追踪: 从起始铁轨沿一个方向走到尽头; 闭环时自动识别并去掉回到起点的重复一步。
    """
    if not _is_rail(get_block(start_rail)):
        return [], False
    path, looped = _walk(get_block, start_rail, None, max_len)
    if looped and len(path) > 2 and path[0] == path[-1]:
        path = path[:-1]
    return path, looped


def _walk(get_block, start, blocked_pos, max_len):
    path = [start]
    visited = {start}
    cur = start
    prev = None
    looped = False
    while len(path) < max_len:
        name, aux = _name_aux(get_block(cur))
        data = rail_data(name, aux)
        conns = RAIL_CONNS.get(data, [])
        nxt = None
        for dc in conns:
            np = (cur[0] + dc[0], cur[1] + dc[1], cur[2] + dc[2])
            if np == prev or np == blocked_pos:
                continue
            if _is_rail(get_block(np)):
                nxt = np
                break
        if nxt is None or nxt in visited:
            if nxt == start:
                looped = True
            break
        path.append(nxt)
        visited.add(nxt)
        prev = cur
        cur = nxt
    return path, looped


def _is_rail(block):
    name, _ = _name_aux(block)
    return name in RAIL_BLOCKS


def find_start_rail(get_block, feet_pos, search_radius=2):
    """
    在玩家脚下附近找铁轨。feet_pos: (x,y,z) 玩家脚部坐标
    返回铁轨方块坐标或 None
    """
    x, y, z = feet_pos
    # 优先: 正下方 / 脚下 / 偏下1格
    candidates = []
    for dy in (-2, -1, 0, 1):
        for dx in range(-search_radius, search_radius + 1):
            for dz in range(-search_radius, search_radius + 1):
                candidates.append((x + dx, y + dy, z + dz))
    for pos in candidates:
        if _is_rail(get_block(pos)):
            return pos
    return None


def find_rail_nearby(get_block, feet_pos, radius=5):
    """
    在玩家周围 radius 格内找最近的铁轨(手持物品生成列车用)。
    feet_pos: 玩家脚部坐标。优先脚下, 再按水平距离从小到大搜索。
    返回铁轨方块坐标或 None。
    """
    x, y, z = feet_pos
    # 1) 脚下优先
    for dy in (-2, -1, 0, 1):
        for dx in (-1, 0, 1):
            for dz in (-1, 0, 1):
                p = (x + dx, y + dy, z + dz)
                if _is_rail(get_block(p)):
                    return p
    # 2) 按水平距离从小到大
    best = None
    best_d = None
    for dy in range(-2, 3):
        for dx in range(-radius, radius + 1):
            for dz in range(-radius, radius + 1):
                p = (x + dx, y + dy, z + dz)
                if not _is_rail(get_block(p)):
                    continue
                d = dx * dx + dz * dz
                if best_d is None or d < best_d:
                    best_d = d
                    best = p
    return best


def _chaikin(pts, iterations=1, closed=False):
    """Chaikin 平滑: 磨圆弯道拐点, 直线段不受影响"""
    for _ in range(iterations):
        n = len(pts)
        if n < 3:
            return pts
        out = []
        if not closed:
            out.append(pts[0])
        for i in range(n):
            a = pts[i]
            b = pts[(i + 1) % n] if closed else (pts[i + 1] if i + 1 < n else None)
            if b is None:
                continue
            out.append((0.75 * a[0] + 0.25 * b[0], 0.75 * a[1] + 0.25 * b[1], 0.75 * a[2] + 0.25 * b[2]))
            out.append((0.25 * a[0] + 0.75 * b[0], 0.25 * a[1] + 0.75 * b[1], 0.25 * a[2] + 0.75 * b[2]))
        if not closed:
            out.append(pts[-1])
        pts = out
    return pts


def _resample_uniform(pts, spacing=0.25, closed=False):
    """沿折线按固定弧长均匀重采样, 消除 Catmull-Rom 非均匀间距摆动。
    闭环按 总长/整数段数 自适应间距, 保证首尾精确闭合。"""
    import math
    if len(pts) < 2:
        return list(pts)
    n = len(pts)
    total_edges = n if closed else n - 1
    # 先算折线总长
    total_len = 0.0
    for i in range(total_edges):
        a = pts[i]
        b = pts[(i + 1) % n]
        total_len += math.sqrt((b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2 + (b[2] - a[2]) ** 2)
    if closed:
        # 闭环: 用 总长/整数段数, 使采样首尾恰好相接
        n_seg = max(3, int(round(total_len / spacing)))
        spacing = total_len / n_seg
    out = [pts[0]]
    cur = pts[0]
    acc = spacing          # 距下一个输出点的弧长
    i = 0
    while i < total_edges:
        nxt = pts[(i + 1) % n]
        dx, dy, dz = nxt[0] - cur[0], nxt[1] - cur[1], nxt[2] - cur[2]
        seg = math.sqrt(dx * dx + dy * dy + dz * dz)
        if seg < 1e-6:
            i += 1
            cur = nxt
            continue
        while acc <= seg:
            t = acc / seg
            out.append((cur[0] + dx * t, cur[1] + dy * t, cur[2] + dz * t))
            acc += spacing
        acc -= seg
        i += 1
        cur = nxt
    # 去重相邻重复点(闭环采样恰好落在首点时)
    dedup = []
    for q in out:
        if dedup and abs(q[0] - dedup[-1][0]) < 1e-6 and abs(q[2] - dedup[-1][2]) < 1e-6:
            continue
        dedup.append(q)
    out = dedup
    if closed:
        # 闭环: 不补首点(TrainTrack closed 模式自带环绕), 去掉与首点重合的末点
        if len(out) > 1 and abs(out[-1][0] - out[0][0]) < 1e-6 and abs(out[-1][2] - out[0][2]) < 1e-6:
            out.pop()
    else:
        # 开放: 补终点
        last = pts[-1]
        if abs(out[-1][0] - last[0]) > 1e-6 or abs(out[-1][2] - last[2]) > 1e-6:
            out.append(last)
    return out


def build_track_from_rails(get_block, start_rail, offset_y=0.35):
    """
    追踪铁轨并构建 TrainTrack (自动识别闭环/开放线路)。
    处理管线: 方块中心点 -> 弯道替换为 1 格半径四分之一圆弧(矿车切弯路径)
              -> 均匀重采样 -> Catmull-Rom 样条
    返回 (track, origin, 路径长度) 或 (None, None, 0)
    """
    import math
    path, is_loop = trace_rails(get_block, start_rail)
    if len(path) < 2:
        return None, None, len(path)
    pts = []
    npath = len(path)
    for i, p in enumerate(path):
        name, aux = _name_aux(get_block(p))
        data = rail_data(name, aux)
        cx, cy, cz = p[0] + 0.5, p[1] + offset_y, p[2] + 0.5
        if data in (6, 7, 8, 9) and npath >= 3:
            if is_loop:
                A = path[(i - 1) % npath]
                B = path[(i + 1) % npath]
            else:
                if i <= 0 or i + 1 >= npath:
                    pts.append((cx, cy, cz))
                    continue
                A = path[i - 1]
                B = path[i + 1]
            ax, az = A[0] + 0.5, A[2] + 0.5
            bx, bz = B[0] + 0.5, B[2] + 0.5
            # 入向方向决定圆心: E-W 入向 -> O=(ax,bz); N-S 入向 -> O=(bx,az)
            if abs(cx - ax) > abs(cz - az):
                ox, oz = ax, bz
            else:
                ox, oz = bx, az
            r = math.hypot(ax - ox, az - oz)
            if r < 1e-6:
                pts.append((cx, cy, cz))
                continue
            ang_a = math.atan2(az - oz, ax - ox)
            ang_b = math.atan2(bz - oz, bx - ox)
            d = ang_b - ang_a
            while d > math.pi:
                d -= 2 * math.pi
            while d < -math.pi:
                d += 2 * math.pi
            # 角点中心不在路径上: 插入圆弧内部采样点(端点=邻块中心, 已有)
            for k in range(1, 8):
                th = ang_a + d * k / 8.0
                pts.append((ox + r * math.cos(th), cy, oz + r * math.sin(th)))
        else:
            pts.append((cx, cy, cz))
    pts = _resample_uniform(pts, spacing=0.25, closed=is_loop)
    origin = pts[0]
    rel = [(p[0] - origin[0], p[1] - origin[1], p[2] - origin[2]) for p in pts]
    track = TrainTrack(rel, closed=is_loop)
    return track, origin, len(path)
