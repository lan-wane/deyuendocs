# -*- coding: utf-8 -*-
"""
德元轨道交通 - 轨道样条
Catmull-Rom 样条 + 弧长表, 提供按里程取点/朝向, 保证列车过弯丝滑匀速
- closed=True  : 闭合环路(首尾相接, 里程取模)
- closed=False : 开放线路(从起点到终点, 里程钳制在 [0,total])
"""
import math

# 曲线限速(物理约束): 过弯丝滑
CURVE_LAT_ACC = 5.0      # 允许的横向加速度 m/s^2
CURVE_MIN_SPEED = 2.5    # 急弯最低限速 m/s (9 km/h, 保证丝滑)
CURVE_MAX_SPEED = 33.3   # 限速上限 m/s (120 km/h)
CURVE_LOOKAHEAD = 150.0  # 前瞻距离 m: 按制动距离提前减速(120km/h 需约 135m)
PROFILE_STEP = 0.25      # 限速剖面网格 m


class TrainTrack(object):
    def __init__(self, waypoints, samples_per_seg=64, closed=True):
        self.pts = [(float(x), float(y), float(z)) for x, y, z in waypoints]
        self.n = len(self.pts)
        self.samples = samples_per_seg
        self.closed = closed
        self.points = []   # 密集采样点
        self.arcs = []     # 累计弧长
        self.total = 0.0
        self.curve = []    # 每采样点曲率(rad/m)
        self.profile = []  # 前瞻限速剖面(0.25m 网格)
        self.profile_arcs = []
        self._build()
        self._build_limits()

    # ---- Catmull-Rom 采样 ----
    def _seg(self, i):
        """返回第 i 段样条的 4 个控制点 (闭合环绕 / 开放钳制)"""
        n = self.n
        if self.closed:
            p0 = self.pts[(i - 1) % n]
            p1 = self.pts[i]
            p2 = self.pts[(i + 1) % n]
            p3 = self.pts[(i + 2) % n]
        else:
            p1 = self.pts[i]
            p2 = self.pts[min(i + 1, n - 1)]
            p0 = self.pts[max(i - 1, 0)]
            p3 = self.pts[min(i + 2, n - 1)]
            # 端点切线自然延伸: 首段 p0=p1, 末段 p3=p2
            if i == 0:
                p0 = p1
            if i == n - 2:
                p3 = p2
        return p0, p1, p2, p3

    @staticmethod
    def _eval(p0, p1, p2, p3, t):
        """Catmull-Rom 插值 (统一参数化)"""
        t2 = t * t
        t3 = t2 * t
        x = 0.5 * ((2 * p1[0]) + (-p0[0] + p2[0]) * t +
                   (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * t2 +
                   (-p0[0] + 3 * p1[0] - 3 * p2[0] + p3[0]) * t3)
        y = 0.5 * ((2 * p1[1]) + (-p0[1] + p2[1]) * t +
                   (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2 +
                   (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * t3)
        z = 0.5 * ((2 * p1[2]) + (-p0[2] + p2[2]) * t +
                   (2 * p0[2] - 5 * p1[2] + 4 * p2[2] - p3[2]) * t2 +
                   (-p0[2] + 3 * p1[2] - 3 * p2[2] + p3[2]) * t3)
        return x, y, z

    @staticmethod
    def _deriv(p0, p1, p2, p3, t):
        t2 = t * t
        dx = 0.5 * ((-p0[0] + p2[0]) +
                    (2 * p0[0] - 10 * p1[0] + 8 * p2[0] - 2 * p3[0]) * t +
                    (-3 * p0[0] + 9 * p1[0] - 9 * p2[0] + 3 * p3[0]) * t2)
        dy = 0.5 * ((-p0[1] + p2[1]) +
                    (2 * p0[1] - 10 * p1[1] + 8 * p2[1] - 2 * p3[1]) * t +
                    (-3 * p0[1] + 9 * p1[1] - 9 * p2[1] + 3 * p3[1]) * t2)
        dz = 0.5 * ((-p0[2] + p2[2]) +
                    (2 * p0[2] - 10 * p1[2] + 8 * p2[2] - 2 * p3[2]) * t +
                    (-3 * p0[2] + 9 * p1[2] - 9 * p2[2] + 3 * p3[2]) * t2)
        return dx, dy, dz

    def _build(self):
        pts = []
        arcs = []
        total = 0.0
        segs = self.n if self.closed else self.n - 1
        for i in range(segs):
            p0, p1, p2, p3 = self._seg(i)
            for k in range(self.samples):
                t = float(k) / float(self.samples)
                cur = self._eval(p0, p1, p2, p3, t)
                if pts:
                    total += math.sqrt((cur[0] - pts[-1][0]) ** 2 +
                                       (cur[1] - pts[-1][1]) ** 2 +
                                       (cur[2] - pts[-1][2]) ** 2)
                pts.append(cur)
                arcs.append(total)
        if not self.closed:
            # 追加开放线路终点
            cur = self.pts[-1]
            if pts:
                total += math.sqrt((cur[0] - pts[-1][0]) ** 2 +
                                   (cur[1] - pts[-1][1]) ** 2 +
                                   (cur[2] - pts[-1][2]) ** 2)
            pts.append(cur)
            arcs.append(total)
        self.points = pts
        self.arcs = arcs
        self.total = total

    def _build_limits(self):
        """按密集采样点切线方向变化率计算曲率表"""
        n = len(self.points)
        curve = [0.0] * n
        for i in range(n):
            j = (i + 1) % n if self.closed else min(i + 1, n - 1)
            if i == j:
                break
            a = self.points[i]
            b = self.points[j]
            dx, dy, dz = b[0] - a[0], b[1] - a[1], b[2] - a[2]
            ds = math.sqrt(dx * dx + dy * dy + dz * dz)
            if ds < 1e-6:
                continue
            yaw0 = self._tangent_to_rot((dx, dy, dz))[0]
            # 用相邻两段的方向差估算曲率
            k2 = (j + 1) % n if self.closed else min(j + 1, n - 1)
            if k2 < n and k2 != j:
                c = self.points[k2]
                dx2, dy2, dz2 = c[0] - b[0], c[1] - b[1], c[2] - b[2]
                ds2 = math.sqrt(dx2 * dx2 + dy2 * dy2 + dz2 * dz2)
                if ds2 > 1e-6:
                    yaw1 = self._tangent_to_rot((dx2, dy2, dz2))[0]
                    dyaw = yaw1 - yaw0
                    if dyaw > 180.0:
                        dyaw -= 360.0
                    elif dyaw < -180.0:
                        dyaw += 360.0
                    curve[i] = abs(math.radians(dyaw)) / max(ds + ds2, 1e-6)
        self.curve = curve
        self._build_profile()

    def speed_limit(self, s):
        """里程 s 处的限速 (曲线限速, 平滑插值)"""
        if self.closed:
            s = s % self.total
        else:
            s = max(0.0, min(s, self.total))
        idx = self._lower_bound(self.arcs, s)
        idx = max(0, min(idx, len(self.curve) - 1))
        k = self.curve[idx]
        if k <= 1e-6:
            return CURVE_MAX_SPEED
        v = math.sqrt(CURVE_LAT_ACC / k)
        return max(CURVE_MIN_SPEED, min(CURVE_MAX_SPEED, v))

    def _build_profile(self):
        """
        前瞻限速剖面: 每个网格点的限速 = 其前方 LOOKAHEAD 窗口内的最小限速。
        列车按此剖面减速, 能在进弯前提前刹到弯道限速, 保证丝滑。
        """
        n = int(math.ceil(self.total / PROFILE_STEP)) + 1
        raw = [self.speed_limit(min(i * PROFILE_STEP, self.total)) for i in range(n)]
        window = max(1, int(CURVE_LOOKAHEAD / PROFILE_STEP))
        out = [0.0] * n
        for i in range(n):
            best = CURVE_MAX_SPEED
            for j in range(window + 1):
                v = raw[(i + j) % n]
                if v < best:
                    best = v
            out[i] = best
        self.profile = out
        self.profile_arcs = [min(i * PROFILE_STEP, self.total) for i in range(n)]

    def limit_at(self, s):
        """前瞻限速: 查询剖面"""
        if self.closed:
            s = s % self.total
        else:
            s = max(0.0, min(s, self.total))
        idx = self._lower_bound(self.profile_arcs, s)
        idx = max(0, min(idx, len(self.profile) - 1))
        return self.profile[idx]

    # ---- 按里程查询 ----
    def point_at(self, s):
        """里程 s (0..total) -> (pos, yaw_deg, pitch_deg)"""
        if self.closed:
            s = s % self.total
        else:
            s = max(0.0, min(s, self.total))
        idx = self._lower_bound(self.arcs, s)
        idx = max(1, min(idx, len(self.arcs) - 1))
        a0 = self.arcs[idx - 1]
        a1 = self.arcs[idx]
        p0 = self.points[idx - 1]
        p1 = self.points[idx]
        if a1 - a0 <= 1e-6:
            pos = p1
            tangent = self._tangent(idx)
        else:
            t = (s - a0) / (a1 - a0)
            pos = (p0[0] + (p1[0] - p0[0]) * t,
                   p0[1] + (p1[1] - p0[1]) * t,
                   p0[2] + (p1[2] - p0[2]) * t)
            tangent = (p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2])
        yaw, pitch = self._tangent_to_rot(tangent)
        return pos, yaw, pitch

    def _tangent(self, idx):
        n = len(self.points)
        a = self.points[(idx - 1) % n]
        b = self.points[idx % n]
        return (b[0] - a[0], b[1] - a[1], b[2] - a[2])

    def _tangent_to_rot(self, tangent):
        dx, dy, dz = tangent
        hor = math.sqrt(dx * dx + dz * dz)
        if hor < 1e-6:
            yaw = 0.0
        else:
            # 我的世界朝向: yaw=0 朝向 +Z, 顺时针为正
            yaw = math.degrees(math.atan2(-dx, dz))
        pitch = math.degrees(math.atan2(dy, hor)) if hor > 1e-6 else 0.0
        return yaw, pitch

    def nearest_arc(self, target_pos):
        """返回离目标点最近的里程"""
        best = 0
        best_d = None
        for i, p in enumerate(self.points):
            d = (p[0] - target_pos[0]) ** 2 + (p[1] - target_pos[1]) ** 2 + (p[2] - target_pos[2]) ** 2
            if best_d is None or d < best_d:
                best_d = d
                best = i
        return self.arcs[best]

    def _lower_bound(self, arr, val):
        lo, hi = 0, len(arr) - 1
        while lo < hi:
            mid = (lo + hi) // 2
            if arr[mid] < val:
                lo = mid + 1
            else:
                hi = mid
        return lo
