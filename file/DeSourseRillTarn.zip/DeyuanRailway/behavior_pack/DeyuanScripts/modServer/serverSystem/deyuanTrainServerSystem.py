# -*- coding: utf-8 -*-
"""
德元轨道交通 - 服务端系统 (6B 编组, 纯手动)
- 手持物品 "deyuan:train_item"(6B编组列车) 右键: 在玩家半径<5内找铁轨生成列车
- 上车: 右键车厢坐到座位; 驾驶 UI: P1-P4 牵引加速, EB 急停
- 车门: UI 左门/右门 按钮分别控制
- 线路: 单向追踪玩家铁轨(矿车铁轨), 支持直/弯/上坡, 自动识别闭环
转向架/车体稳定: 两转向架沿轨, 车体弦线, 过弯偏转+温和侧倾。
"""
import math

import mod.server.extraServerApi as serverApi
from mod_log import logger

from DeyuanScripts.modCommon import modConfig as C
from DeyuanScripts.modServer.serverSystem import railTrack

ServerSystem = serverApi.GetServerSystemCls()
compFactory = serverApi.GetEngineCompFactory()


class DeyuanTrainServerSystem(ServerSystem):
    def __init__(self, namespace, systemName):
        ServerSystem.__init__(self, namespace, systemName)
        self.trains = {}
        self.nextTrainId = 1
        self.track = None
        self.origin = None
        self.dimension = 0
        self.players = set()
        self.carYaw = {}
        self.simpleMode = C.SimpleMode
        self._listen()

    # ---------------- 事件 ----------------
    def _listen(self):
        ns = serverApi.GetEngineNamespace()
        es = serverApi.GetEngineSystemName()
        self.ListenForEvent(ns, es, C.OnScriptTickServer, self, self.OnTick)
        self.ListenForEvent(ns, es, C.ServerChatEvent, self, self.OnChat)
        self.ListenForEvent(ns, es, C.AddServerPlayerEvent, self, self.OnPlayerJoin)
        self.ListenForEvent(ns, es, C.EntityStartRidingEvent, self, self.OnRideStart)
        self.ListenForEvent(ns, es, C.EntityStopRidingEvent, self, self.OnRideStop)
        self.ListenForEvent(ns, es, C.EntityUseItemOnEvent, self, self.OnUseItem)
        self.ListenForEvent(C.ModName, C.ClientSystemName, C.NotchEvent, self, self.OnNotch)
        self.ListenForEvent(C.ModName, C.ClientSystemName, C.DoorSideEvent, self, self.OnDoorSide)

    def OnPlayerJoin(self, args):
        playerId = args.get("id") or args.get("playerId")
        if playerId:
            self.players.add(playerId)

    def OnChat(self, args):
        playerId = args.get("playerId") or (list(self.players)[0] if self.players else None)
        if not playerId:
            return
        msg = (args.get("message") or "").strip().lower().lstrip("/")
        if msg == C.CmdBuild or msg == C.CmdBuildFull:
            self.CmdBuildFromFeet(playerId)
        elif msg == C.CmdStop:
            self.StopTrain()
            self._tell(playerId, "列车已移除")
        elif msg == C.CmdSimple:
            self.simpleMode = not self.simpleMode
            self._tell(playerId, "简易模式: %s (EB %s)" % (
                "开" if self.simpleMode else "关",
                "0 秒瞬间停车" if self.simpleMode else "标准急停"))
        elif msg == C.CmdHelp:
            self._help(playerId)

    def _help(self, playerId):
        for line in [
            "德元轨道交通 6B 编组 - 手动驾驶",
            "生成: 手持 [6B编组列车] 物品, 站在铁轨附近右键",
            "dy stop : 移除列车 | dy simple : 简易模式 | dy help : 帮助",
            "上车: 右键车厢坐到座位; 驾驶: P1-P4 牵引加速, EB 急停, 再按同级松牵引",
            "车门: 驾驶UI 左门/右门 按钮分别控制",
        ]:
            self._tell(playerId, line)

    # ---------------- 物品生成列车(主入口) ----------------
    def OnUseItem(self, args):
        playerId = args.get("playerId") or args.get("id")
        itemDict = args.get("itemDict") or args.get("item") or {}
        itemName = itemDict.get("newItemName") or itemDict.get("name") or ""
        if not playerId or itemName != C.TrainItemName:
            return
        posComp = compFactory.CreatePos(playerId)
        if not posComp:
            return
        feet = posComp.GetPos()
        self.dimension = posComp.GetDimensionId()
        start = railTrack.find_rail_nearby(self._getBlock, (feet[0], feet[1], feet[2]), C.SpawnSearchRadius)
        if start is None:
            self._tell(playerId, "附近 %d 格内没有铁轨, 请靠近原版铁轨再右键" % C.SpawnSearchRadius)
            return
        self._buildAndSpawn(playerId, start)

    def CmdBuildFromFeet(self, playerId):
        self.StopTrain()
        posComp = compFactory.CreatePos(playerId)
        if not posComp:
            return
        feet = posComp.GetPos()
        self.dimension = posComp.GetDimensionId()
        start = railTrack.find_rail_nearby(self._getBlock, (feet[0], feet[1], feet[2]), C.SpawnSearchRadius)
        if start is None:
            self._tell(playerId, "附近没有找到铁轨, 请靠近原版铁轨")
            return
        self._buildAndSpawn(playerId, start)

    def _buildAndSpawn(self, playerId, start):
        self.StopTrain()
        track, origin, n = railTrack.build_track_from_rails(self._getBlock, start)
        if track is None:
            self._tell(playerId, "铁轨不连续或太短(至少 2 格)")
            return
        self.track = track
        self.origin = origin
        self._spawnTrain()
        self._tell(playerId, "已生成 6B 编组: 全长 %.0f 米(%s), 6 节车厢已上线" % (
            track.total, "闭环" if track.closed else "开放"))
        self._tell(playerId, "右键车厢上车; P1-P4 牵引, EB 急停, 左/右门按钮开关门")

    def _getBlock(self, pos):
        try:
            bi = compFactory.CreateBlockInfo(serverApi.GetLevelId())
            return bi.GetBlockNew(pos)
        except Exception:
            try:
                bi = compFactory.CreateBlockInfo(serverApi.GetLevelId())
                return bi.GetBlock(pos)
            except Exception:
                return None

    # ---------------- 列车生成 / 移除 ----------------
    def _spawnTrain(self):
        origin = self.origin
        carIds = []
        for i, etype in enumerate(C.CarEntities):
            s = (0.0 - i * C.CarSpacing) % self.track.total
            pos, yaw, pitch = self.track.point_at(s)
            worldPos = (origin[0] + pos[0], origin[1] + pos[1], origin[2] + pos[2])
            carId = self.CreateEngineEntityByTypeStr(etype, worldPos, (yaw, pitch, 0.0), self.dimension)
            if not carId:
                logger.warn("Deyuan: spawn car %s failed", etype)
                continue
            carIds.append(carId)
            self.carYaw[carId] = yaw
            self._setPersistence(carId)
        if not carIds:
            logger.warn("Deyuan: no car spawned")
            return
        trainId = self.nextTrainId
        self.nextTrainId += 1
        self.trains[trainId] = {
            "carIds": carIds,
            "speed": 0.0,
            "notch": 0,
            "dist": 0.0,
            "doorsLeft": False,
            "doorsRight": False,
            "riders": {},
            "tick": 0,
        }
        self.BroadcastToAllClient(C.TrainCarsEvent, {"carIds": carIds, "register": True})
        logger.info("Deyuan: train %s spawned with %d cars", trainId, len(carIds))

    def StopTrain(self):
        for train in self.trains.values():
            for carId in train["carIds"]:
                try:
                    self.DestroyEntity(carId)
                except Exception:
                    pass
            for riderId in list(train.get("riders", {}).keys()):
                self.NotifyToClient(riderId, C.RideStateEvent, {"riding": False})
            self.BroadcastToAllClient(C.TrainCarsEvent, {"carIds": train["carIds"], "register": False})
        self.trains = {}
        self.carYaw = {}

    def _setPersistence(self, carId):
        try:
            comp = compFactory.CreateGame(serverApi.GetLevelId())
            comp.SetPersistence(carId, True)
        except Exception:
            pass

    # ---------------- 上下车 ----------------
    def _find_train_by_car(self, carId):
        for train in self.trains.values():
            if carId in train["carIds"]:
                return train
        return None

    def OnRideStart(self, args):
        riderId = args.get("riderId") or args.get("playerId") or args.get("id")
        carId = args.get("entityId") or args.get("carId")
        if not riderId or not carId:
            return
        train = self._find_train_by_car(carId)
        if train is None:
            return
        train["riders"][riderId] = carId
        self.NotifyToClient(riderId, C.RideStateEvent, {"riding": True})

    def OnRideStop(self, args):
        riderId = args.get("riderId") or args.get("playerId") or args.get("id")
        if not riderId:
            return
        for train in self.trains.values():
            if riderId in train.get("riders", {}):
                train["riders"].pop(riderId, None)
                self.NotifyToClient(riderId, C.RideStateEvent, {"riding": False})
                break

    # ---------------- 牵引 / 急停 ----------------
    def OnNotch(self, args):
        playerId = args.get("playerId")
        notchKey = args.get("notch")
        if not playerId or not notchKey:
            return
        for train in self.trains.values():
            if playerId in train.get("riders", {}):
                self.ApplyNotch(train, notchKey, playerId)
                return

    def ApplyNotch(self, train, notchKey, playerId=None):
        key = notchKey.upper()
        if key == "EB":
            train["notch"] = -1 if train["notch"] != -1 else 0
        else:
            try:
                level = int(key[1:])
            except Exception:
                return
            if level < 1 or level > 4:
                return
            # 牵引级位: 再按同级松牵引(回 0=惰行)
            train["notch"] = 0 if train["notch"] == level else level
        if playerId:
            self._tell(playerId, self.NotchName(train["notch"]))

    def NotchName(self, notch):
        if notch == -1:
            return "急停EB(%s)" % ("0秒" if self.simpleMode else "标准")
        if notch == 0:
            return "惰行"
        return "牵引P%d" % notch

    # ---------------- 左/右门 ----------------
    def OnDoorSide(self, args):
        playerId = args.get("playerId")
        side = (args.get("side") or "").lower()
        if not playerId or side not in ("left", "right"):
            return
        for train in self.trains.values():
            if playerId in train.get("riders", {}):
                if side == "left":
                    train["doorsLeft"] = not train["doorsLeft"]
                else:
                    train["doorsRight"] = not train["doorsRight"]
                self.BroadcastToAllClient(C.DoorStateEvent, {
                    "carIds": train["carIds"],
                    "left": train["doorsLeft"],
                    "right": train["doorsRight"],
                })
                sideCn = "左" if side == "left" else "右"
                key = "doorsLeft" if side == "left" else "doorsRight"
                stateCn = "开" if train[key] else "关"
                self._tell(playerId, sideCn + "门: " + stateCn)
                return

    # ---------------- 每帧逻辑 ----------------
    def OnTick(self):
        if not self.trains:
            return
        for train in self.trains.values():
            self.UpdateTrain(train)
        self._broadcastStates()

    def UpdateTrain(self, train):
        dt = 1.0 / 20.0
        speed = train["speed"]
        notch = train["notch"]
        total = self.track.total
        limit = self.track.limit_at(train["dist"])

        if notch == 0:
            # 惰行: 自然阻力; 进弯按 CurveDecel 提前减速
            if speed > limit:
                speed -= min(speed - limit, C.CurveDecel * dt)
            else:
                speed -= C.Friction * dt
        elif 1 <= notch <= 4:
            # 牵引加速, 不超过曲线限速
            accel = C.TractionP.get(notch, C.TractionP[1])
            if speed < limit:
                speed = min(limit, speed + accel * dt)
            else:
                speed -= min(speed - limit, C.CurveDecel * dt)
        elif notch == -1:
            # EB 急停
            if self.simpleMode:
                speed = 0.0
            else:
                speed -= C.EmergencyBrake * dt
        if speed < 0.0:
            speed = 0.0

        train["speed"] = speed
        if self.track.closed:
            train["dist"] = (train["dist"] + speed * dt) % total
        else:
            train["dist"] = min(total, train["dist"] + speed * dt)
            if train["dist"] >= total:
                train["speed"] = 0.0

        origin = self.origin
        h = C.BogieHalfDist
        for i, carId in enumerate(train["carIds"]):
            if self.track.closed:
                s = (train["dist"] - i * C.CarSpacing) % total
            else:
                s = max(0.0, min(total, train["dist"] - i * C.CarSpacing))
            self._poseCar(carId, s, speed, origin)

    def _poseCar(self, carId, s, speed, origin):
        tr = self.track
        h = C.BogieHalfDist
        if tr.closed:
            sf = (s + h) % tr.total
            sb = (s - h) % tr.total
        else:
            sf = max(0.0, min(tr.total, s + h))
            sb = max(0.0, min(tr.total, s - h))
        pf, yaw_f, pitch_f = tr.point_at(sf)
        pb, yaw_b, pitch_b = tr.point_at(sb)

        cx = (pb[0] + pf[0]) * 0.5
        cy = (pb[1] + pf[1]) * 0.5
        cz = (pb[2] + pf[2]) * 0.5
        worldPos = (origin[0] + cx, origin[1] + cy, origin[2] + cz)

        dx = pf[0] - pb[0]
        dz = pf[2] - pb[2]
        dy = pf[1] - pb[1]
        hor = math.sqrt(dx * dx + dz * dz)
        if hor > 1e-6:
            bodyYaw = math.degrees(math.atan2(-dx, dz))
            bodyPitch = math.degrees(math.atan2(dy, hor))
        else:
            bodyYaw = yaw_f
            bodyPitch = pitch_f

        lastYaw = self.carYaw.get(carId, bodyYaw)
        diff = bodyYaw - lastYaw
        if diff > 180.0:
            diff -= 360.0
        elif diff < -180.0:
            diff += 360.0
        bodyYaw = lastYaw + diff
        self.carYaw[carId] = bodyYaw

        dyaw = yaw_f - yaw_b
        if dyaw > 180.0:
            dyaw -= 360.0
        elif dyaw < -180.0:
            dyaw += 360.0
        curve_rad = abs(math.radians(dyaw)) / max(2.0 * h, 1e-6)
        a_lat = speed * speed * curve_rad
        roll = -math.copysign(
            min(C.BodyRollMaxDeg, C.BodyRollGain * a_lat), dyaw)

        self._moveCar(carId, worldPos, (bodyYaw % 360.0, bodyPitch, roll))

        dRear = self._wrapDeg(yaw_b - bodyYaw)
        dFront = self._wrapDeg(yaw_f - bodyYaw)
        lim = C.BogieDeflectMaxDeg
        dRear = max(-lim, min(lim, dRear))
        dFront = max(-lim, min(lim, dFront))
        self._syncBogieBones(carId, dRear, dFront)

    @staticmethod
    def _wrapDeg(a):
        while a > 180.0:
            a -= 360.0
        while a < -180.0:
            a += 360.0
        return a

    def _syncBogieBones(self, carId, dRear, dFront):
        try:
            td = compFactory.CreateTempData(carId)
            td.SetTempData("dy_bogie_rear", float(dRear))
            td.SetTempData("dy_bogie_front", float(dFront))
        except Exception:
            pass

    def _moveCar(self, carId, pos, rot):
        try:
            posComp = compFactory.CreatePos(carId)
            rotComp = compFactory.CreateRot(carId)
            if posComp:
                posComp.SetPos(pos)
            if rotComp:
                rotComp.SetRot(rot)
        except Exception:
            pass

    def _broadcastStates(self):
        for train in self.trains.values():
            train["tick"] += 1
            if train["tick"] % 20 != 0:
                continue
            for riderId in list(train.get("riders", {}).keys()):
                self.NotifyToClient(riderId, C.TrainStateEvent, {
                    "speed": train["speed"],
                    "notch": train["notch"],
                    "left": train["doorsLeft"],
                    "right": train["doorsRight"],
                })

    def _tell(self, playerId, msg):
        try:
            comp = compFactory.CreateGame(serverApi.GetLevelId())
            comp.NotifyOneMessage(playerId, msg, "f")
        except Exception:
            pass
