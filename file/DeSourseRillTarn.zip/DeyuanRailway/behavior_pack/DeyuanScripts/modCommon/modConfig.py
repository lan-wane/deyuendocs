# -*- coding: utf-8 -*-
"""
德元轨道交通 - 全局配置
"""

ModName = "DeyuanRailway"
ModVersion = "2.0.0"

# 系统注册
ServerSystemName = "DeyuanTrainServerSystem"
ServerSystemClsPath = "DeyuanScripts.modServer.serverSystem.deyuanTrainServerSystem.DeyuanTrainServerSystem"
ClientSystemName = "DeyuanTrainClientSystem"
ClientSystemClsPath = "DeyuanScripts.modClient.clientSystem.deyuanTrainClientSystem.DeyuanTrainClientSystem"
UIClsPath = "DeyuanScripts.modClient.ui.deyuanTrainScreen.DeyuanTrainScreen"
UIScreenDef = "train_ui.main"

# 列车编组: 现实 6B 编组 = 1 车头 + 4 中间车 + 1 尾车 (两端带司机室)
CarCount = 6
CarEntities = ["deyuan:train_car_%d" % i for i in range(1, CarCount + 1)]
# 车型映射: 1=车头(头车), 2..5=中间车, 6=尾车
CarIsHead = {1: True, 6: True}
CarLength = 22.0          # 节车长度(米), 1:1
CarSpacing = 22.0         # 车头间距(米)

# 物品: "6B编组列车" 手持右键, 在玩家半径 R<5 内找最近铁轨生成列车
TrainItemName = "deyuan:train_item"
SpawnSearchRadius = 5

# 转向架几何(米): 模型 pivot z=±116px, 16px=1m -> 半转向架中心距 7.25m
# bogie1(z=-116)=后转向架, bogie2(z=+116)=前转向架(车头在 +Z)
BogieHalfDist = 7.25      # 车中心到单个转向架的纵向距离
BogieBoneRear = "bogie1"  # 后转向架骨骼名(模型 -Z 端)
BogieBoneFront = "bogie2" # 前转向架骨骼名(模型 +Z 端)

# 车体稳定(过弯姿态): 车体走前后转向架连线(弦线), 并按横向加速度微侧倾
BodyRollMaxDeg = 2.5      # 过弯车体侧倾上限(度, 温和不漂移)
BodyRollGain = 0.12       # 侧滚增益: roll(度) = -gain * v^2 * curvature(rad/m)
BogieDeflectMaxDeg = 40.0 # 转向架相对车体偏转视觉上限(度): 急弯限幅, 避免轮对横飞

# 牵引 / 急停参数 (m/s^2)
# P1-P4 为牵引级位(加速递增), EB 为急停; 默认 notch=0 为惰行(自然阻力减速, 不牵引)
CruiseSpeed = 33.3        # 牵引目标巡航 120 km/h
TractionP = {1: 0.8, 2: 1.4, 3: 2.0, 4: 2.8}   # P1-P4 牵引加速度(递增)
Friction = 0.08           # 惰行自然减速度
EmergencyBrake = 6.0      # EB 急停减速度(标准模式)
CurveDecel = 3.0          # 曲线限速时的自然减速(物理约束, 保证过弯丝滑)

# 设置: 简易模式
# True  = 简易模式: EB 急停 0 秒(瞬间停车), 适合新手
# False = 标准模式: EB 按 EmergencyBrake m/s^2 急停
# 游戏中可用聊天命令 dy simple 切换(运行时开关), 此值为打包默认
SimpleMode = False

# 事件: 引擎
OnScriptTickServer = "OnScriptTickServer"
ServerChatEvent = "ServerChatEvent"
AddServerPlayerEvent = "AddServerPlayerEvent"
EntityStartRidingEvent = "EntityStartRidingEvent"
EntityStopRidingEvent = "EntityStopRidingEvent"
EntityUseItemOnEvent = "EntityUseItemOnEvent"   # 手持物品右键(生成列车)

# 事件: 自定义
NotchEvent = "DeYuanNotch"              # 客户端 -> 服务端: 牵引级位
DoorSideEvent = "DeYuanDoorSide"        # 客户端 -> 服务端: 开关指定侧门(left/right)
DoorStateEvent = "DeYuanDoorState"      # 服务端 -> 客户端: 左右门状态
RideStateEvent = "DeYuanRideState"      # 服务端 -> 客户端: 上下车
TrainStateEvent = "DeYuanTrainState"    # 服务端 -> 客户端: 列车状态(速度/牵引/门)
TrainCarsEvent = "DeYuanTrainCars"      # 服务端 -> 客户端: 注册/注销车厢(转向架骨骼驱动)

# 命令 (聊天栏, 调试后备; 主入口为手持物品右键)
CmdBuild = "dy"             # 从玩家脚下的原版铁轨生成线路并上线列车
CmdBuildFull = "dy build"
CmdStop = "dy stop"         # 移除列车
CmdSimple = "dy simple"     # 切换简易模式(EB 急停 0 秒)
CmdHelp = "dy help"         # 帮助
