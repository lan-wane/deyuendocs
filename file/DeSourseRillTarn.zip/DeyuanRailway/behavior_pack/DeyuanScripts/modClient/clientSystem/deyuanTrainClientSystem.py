# -*- coding: utf-8 -*-
"""
德元轨道交通 - 客户端系统 (6B 编组)
- 上下车 -> 驾驶UI 显隐
- 左/右门 -> 分别平滑驱动左侧(door_l*)与右侧(door_r*)骨骼
- 转向架 -> bogie1/bogie2 按 TempData 偏转角平滑驱动
"""
import mod.client.extraClientApi as clientApi
from mod_log import logger

from DeyuanScripts.modCommon import modConfig as C

ClientSystem = clientApi.GetClientSystemCls()
compFactory = clientApi.GetEngineCompFactory()

# 左右车门扇骨骼
DOOR_LEFT = ["door_l%d%s" % (i, s) for i in range(1, 5) for s in ("a", "b")]
DOOR_RIGHT = ["door_r%d%s" % (i, s) for i in range(1, 5) for s in ("a", "b")]
DOOR_SLIDE = 0.65     # 单扇门滑动距离(米)
ANIM_SPEED = 0.06     # 车门动画每帧进度

BOGIE_REAR_BONE = "bogie1"
BOGIE_FRONT_BONE = "bogie2"
BOGIE_LERP = 0.35


class DeyuanTrainClientSystem(ClientSystem):
    def __init__(self, namespace, systemName):
        ClientSystem.__init__(self, namespace, systemName)
        self.mPlayerId = clientApi.GetLocalPlayerId()
        self.uiNode = None
        self.uiCreated = False
        self.uiVisible = False
        self.boneOk = True
        # 每车每侧车门动画: carId -> {"left":{progress,target}, "right":{...}, "comp"}
        self.doorAnim = {}
        self.trainCarIds = set()
        self.bogieAnim = {}
        self._listen()

    def _listen(self):
        ns = clientApi.GetEngineNamespace()
        es = clientApi.GetEngineSystemName()
        self.ListenForEvent(ns, es, "UiInitFinished", self, self.OnUiInitFinished)
        self.ListenForEvent(ns, es, "OnScriptTickClient", self, self.OnTickClient)
        self.ListenForEvent(C.ModName, C.ServerSystemName, C.RideStateEvent, self, self.OnRideState)
        self.ListenForEvent(C.ModName, C.ServerSystemName, C.DoorStateEvent, self, self.OnDoorState)
        self.ListenForEvent(C.ModName, C.ServerSystemName, C.TrainStateEvent, self, self.OnTrainState)
        self.ListenForEvent(C.ModName, C.ServerSystemName, C.TrainCarsEvent, self, self.OnTrainCars)

    # ---------------- UI ----------------
    def OnUiInitFinished(self, args):
        try:
            clientApi.RegisterUI(C.ModName, "train_ui", C.UIClsPath, C.UIScreenDef)
            self.uiNode = clientApi.CreateUI(C.ModName, "train_ui", {"isHud": 1})
            if self.uiNode:
                self.uiNode.Init()
                self.uiNode.SetVisible("/trainPanel", False)
                self.uiCreated = True
                logger.info("Deyuan: train UI created")
        except Exception as e:
            logger.warn("Deyuan: UI create error %s", e)

    def OnRideState(self, args):
        riding = bool(args.get("riding"))
        if riding == self.uiVisible:
            return
        self.uiVisible = riding
        if self.uiNode:
            try:
                self.uiNode.SetVisible("/trainPanel", riding)
            except Exception:
                pass

    def OnTrainState(self, args):
        if not self.uiNode or not self.uiVisible:
            return
        try:
            speed = args.get("speed", 0.0)
            notch = args.get("notch", 0)
            left = bool(args.get("left", False))
            right = bool(args.get("right", False))
            kmh = int(round(speed * 3.6))
            if notch == -1:
                notchTxt = "急停"
            elif notch == 0:
                notchTxt = "惰行"
            else:
                notchTxt = "牵引P%d" % notch
            doors = ("左%s " % ("开" if left else "闭")) + ("右%s" % ("开" if right else "闭"))
            self.uiNode.SetText("/trainPanel/statusLabel", "6B线 | %d km/h | %s | %s" % (kmh, notchTxt, doors))
        except Exception:
            pass

    # ---------------- 车厢注册 ----------------
    def OnTrainCars(self, args):
        carIds = args.get("carIds") or []
        register = bool(args.get("register", True))
        if register:
            for cid in carIds:
                self.trainCarIds.add(cid)
                if cid not in self.bogieAnim:
                    self.bogieAnim[cid] = {"rear": 0.0, "front": 0.0, "comp": None}
                if cid not in self.doorAnim:
                    self.doorAnim[cid] = {
                        "left": {"progress": 0.0, "target": 0.0},
                        "right": {"progress": 0.0, "target": 0.0},
                        "comp": None,
                    }
        else:
            for cid in carIds:
                self.trainCarIds.discard(cid)
                self.bogieAnim.pop(cid, None)
                self.doorAnim.pop(cid, None)

    # ---------------- 左右门 ----------------
    def OnDoorState(self, args):
        carIds = args.get("carIds") or []
        left = 1.0 if args.get("left") else 0.0
        right = 1.0 if args.get("right") else 0.0
        for carId in carIds:
            info = self.doorAnim.get(carId)
            if info is None:
                info = {"left": {"progress": 0.0, "target": 0.0},
                        "right": {"progress": 0.0, "target": 0.0}, "comp": None}
                self.doorAnim[carId] = info
            info["left"]["target"] = left
            info["right"]["target"] = right

    def OnTickClient(self):
        self._tickDoors()
        self._tickBogies()

    # ---- 车门 ----
    def _tickDoors(self):
        if not self.boneOk:
            return
        for carId, info in self.doorAnim.items():
            comp = self._doorComp(carId)
            if comp is None:
                continue
            for side, bones in (("left", DOOR_LEFT), ("right", DOOR_RIGHT)):
                d = info[side]
                p, t = d["progress"], d["target"]
                if abs(p - t) < 0.002:
                    p = t
                elif p < t:
                    p = min(t, p + ANIM_SPEED)
                else:
                    p = max(t, p - ANIM_SPEED)
                d["progress"] = p
                for name in bones:
                    slide = (1.0 if name.endswith("b") else -1.0) * DOOR_SLIDE * p
                    try:
                        comp.SetBonePosition(name, (0.0, 0.0, slide))
                    except Exception:
                        pass

    # ---- 转向架 ----
    def _tickBogies(self):
        if not self.trainCarIds or not self.boneOk:
            return
        for carId in list(self.trainCarIds):
            info = self.bogieAnim.get(carId)
            if info is None:
                continue
            tgtRear, tgtFront = self._readBogieTemp(carId)
            info["rear"] += (tgtRear - info["rear"]) * BOGIE_LERP
            info["front"] += (tgtFront - info["front"]) * BOGIE_LERP
            comp = self._bogieComp(carId)
            if comp is None:
                continue
            try:
                comp.SetBoneRotation(BOGIE_REAR_BONE, (0.0, info["rear"], 0.0))
                comp.SetBoneRotation(BOGIE_FRONT_BONE, (0.0, info["front"], 0.0))
            except Exception:
                pass

    def _readBogieTemp(self, carId):
        try:
            td = compFactory.CreateTempData(carId)
            r = td.GetTempData("dy_bogie_rear")
            f = td.GetTempData("dy_bogie_front")
            if r is None or f is None:
                return 0.0, 0.0
            return float(r), float(f)
        except Exception:
            return 0.0, 0.0

    def _doorComp(self, carId):
        info = self.doorAnim.get(carId)
        if info is None:
            return None
        if info["comp"] is None:
            try:
                info["comp"] = compFactory.CreateBone(carId)
            except Exception as e:
                self.boneOk = False
                logger.warn("Deyuan: bone component unavailable (%s), anim disabled", e)
                return None
        return info["comp"]

    def _bogieComp(self, carId):
        info = self.bogieAnim.get(carId)
        if info is None:
            return None
        if info["comp"] is None:
            try:
                info["comp"] = compFactory.CreateBone(carId)
            except Exception as e:
                self.boneOk = False
                logger.warn("Deyuan: bone component unavailable (%s), bogie anim disabled", e)
                return None
        return info["comp"]
