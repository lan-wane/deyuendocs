# -*- coding: utf-8 -*-
"""
德元轨道交通 - 驾驶 UI 屏幕
P1-P4 牵引加速, EB 急停, 左门/右门 按钮
"""
import mod.client.extraClientApi as clientApi
from mod_log import logger

from DeyuanScripts.modCommon import modConfig as C

ScreenNode = clientApi.GetScreenNodeCls()


class DeyuanTrainScreen(ScreenNode):
    def __init__(self, namespace, name, param):
        ScreenNode.__init__(self, namespace, name, param)
        self.mPlayerId = clientApi.GetLocalPlayerId()
        self.panel = "/trainPanel"
        self.buttons = {
            "P4": self.panel + "/p4Button",
            "P3": self.panel + "/p3Button",
            "P2": self.panel + "/p2Button",
            "P1": self.panel + "/p1Button",
            "EB": self.panel + "/ebButton",
            "LEFT": self.panel + "/leftDoorButton",
            "RIGHT": self.panel + "/rightDoorButton",
        }

    def Create(self):
        for key, path in self.buttons.items():
            self.AddTouchEventHandler(path, self._makeHandler(key), {"isSwallow": True})

    def _makeHandler(self, key):
        def handler(args):
            if args.get("TouchEvent") != clientApi.GetMinecraftEnum().TouchEvent.TouchUp:
                return
            system = clientApi.GetSystem(C.ModName, C.ClientSystemName)
            if not system:
                return
            if key == "LEFT":
                system.NotifyToServer(C.DoorSideEvent, {"playerId": self.mPlayerId, "side": "left"})
            elif key == "RIGHT":
                system.NotifyToServer(C.DoorSideEvent, {"playerId": self.mPlayerId, "side": "right"})
            else:
                system.NotifyToServer(C.NotchEvent, {"playerId": self.mPlayerId, "notch": key})
        return handler
