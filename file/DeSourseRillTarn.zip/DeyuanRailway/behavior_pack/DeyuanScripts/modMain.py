# -*- coding: utf-8 -*-
"""德元轨道交通 模组入口"""
from mod.common.mod import Mod
import mod.client.extraClientApi as clientApi
import mod.server.extraServerApi as serverApi

from DeyuanScripts.modCommon import modConfig as C


@Mod.Binding(name=C.ModName, version=C.ModVersion)
class DeyuanRailwayMod(object):
    def __init__(self):
        pass

    @Mod.InitServer()
    def ServerInit(self):
        serverApi.RegisterSystem(C.ModName, C.ServerSystemName, C.ServerSystemClsPath)

    @Mod.InitClient()
    def ClientInit(self):
        clientApi.RegisterSystem(C.ModName, C.ClientSystemName, C.ClientSystemClsPath)
